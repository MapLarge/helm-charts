{{/* vim: set filetype=mustache: */}}

{{/*
Helper function to modify a passed in string to a valid DNS domain segment (required for many Kubernetes fields, including label values)
*/}}
{{- define "dnsSafeTruncate" -}}
{{- print . | replace "+" "_" | trunc 63 | trimSuffix "-" | trimSuffix "_" | trimSuffix "." }}
{{- end}}

{{/*
This is the "name" of the Chart that is used by other templates in this chart to form a qualified name for the application. By default, this is the name of the Chart; can be overriden via `.Values.nameOverride`
*/}}
{{- define "maplarge.name" -}}
{{- include "dnsSafeTruncate" (default .Chart.Name .Values.nameOverride ) }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}

{{- define "maplarge.fullname" -}}
  {{- if .Values.fullnameOverride }}
    {{- include "dnsSafeTruncate" (.Values.fullnameOverride | trunc 52 | lower) }}
  {{- else }}
    {{- $name := default .Chart.Name .Values.nameOverride }}
    {{- if contains $name .Release.Name }}
      {{- include "dnsSafeTruncate" (.Release.Name | trunc 52 | lower) }}
    {{- else }}
      {{- include "dnsSafeTruncate" (printf "%s-%s" .Release.Name $name | trunc 52 | lower) }}
    {{- end }}
  {{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "maplarge.chart" -}}
{{- include "dnsSafeTruncate" (printf "%s-%s" .Chart.Name .Chart.Version) }}
{{- end }}

{{/*
The image tag for the MapLarge API Server. The default (the release this chart
was tested against) is pinned in values.yaml; the schema requires it non-empty.
*/}}
{{- define "maplarge.imageTag" -}}
{{- .Values.image.tag }}
{{- end }}

{{/*
The app version used for the app.kubernetes.io/version label
*/}}
{{- define "maplarge.image" -}}
{{- include "dnsSafeTruncate" (include "maplarge.imageTag" .) }}
{{- end }}

{{/*
Labels that will be applied to every single object
*/}}
{{- define "maplarge.labels" -}}
helm.sh/chart: {{ include "maplarge.chart" . }}
{{ include "maplarge.selectorLabels" . }}
app.kubernetes.io/version: {{ include "maplarge.image" . }}
{{- if .Values.team }}
maplarge.com/project: {{ .Values.team | quote }}
team: {{ .Values.team | quote }}
app.kubernetes.io/owner: {{ .Values.team | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- range $key, $value := .Values.extraLabels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels to point the load balancer service at the appropriate pods
Removed app name from selector labels because now the app name is not going to be the same for all things in the Helm chart.
*/}}
{{- define "maplarge.selectorLabels" -}}
  app.kubernetes.io/instance: {{ include "dnsSafeTruncate" (.Release.Name) }}
{{- end }}

{{/*
Create the name of the headless service to use. The headless service is used for DNS so that MapLarge nodes can communicate with each other.
*/}}
{{- define "maplarge.headlessServiceName" -}}
{{- include "maplarge.fullname" . | trunc 63 }}
{{- end }}

{{/*
Image pull secret name
*/}}
{{- define "maplarge.pullSecretName" }}
{{- .Values.image.pullSecretName }}
{{- end }}

{{/*
`ConfigMap` name
*/}}
{{- define "maplarge.configMapName" }}
{{- include "maplarge.fullname" . -}}-config
{{- end }}

{{/*
Load balancer service name
Naming and length defintions: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#dns-subdomain-names
Max length for a DNS subdomain name is 253
*/}}
{{- define "maplarge.balancerServiceName" }}
{{- $fullnameLen := len (include "maplarge.fullname" .) -}}
{{- $balencerLen := len "-balancer" -}}
{{- $totalLen := add $fullnameLen $balencerLen -}}
{{- $name := "" -}}
{{- if gt $totalLen 253 -}}
  {{- $toTrunc := sub $fullnameLen $balencerLen | int -}}
  {{- $name = include "dnsSafeTruncate" (include "maplarge.fullname" . | trunc $toTrunc ) -}}
{{- else -}}
  {{- $name = include "maplarge.fullname" . -}}
{{- end -}}
{{- printf "%s-%s" $name "balancer" }}
{{- end }}

{{/*
Ingress name
*/}}
{{- define "maplarge.ingressName" }}
{{- include "maplarge.fullname" . -}}-ingress
{{- end }}

{{/*
Root password secret name
*/}}
{{- define "maplarge.rootPasswordSecretName" }}
  {{- if .Values.existingRootPasswordSecretName }}
    {{- .Values.existingRootPasswordSecretName }}
  {{- else if .Values.rootPasswordSecretName }}
    {{- .Values.rootPasswordSecretName }}
  {{- else }}
    {{- include "maplarge.fullname" . -}}-root-password-secret
  {{- end }}
{{- end }}

{{/*
The port the MapLarge container listens on. Uses listenPort if set, otherwise 8443 when
tls.enabled is true, else 8080. Always >= 1024: the container runs as non-root without
NET_BIND_SERVICE and cannot bind privileged ports.
*/}}
{{- define "maplarge.containerPort" -}}
  {{- default (ternary 8443 8080 .Values.tls.enabled) .Values.listenPort -}}
{{- end }}

{{/*
The in-cluster port exposed by the load balancer Service. Uses loadBalancerService.port
if set, otherwise 443 when tls.enabled is true, else 80.
*/}}
{{- define "maplarge.servicePort" -}}
  {{- default (ternary 443 80 .Values.tls.enabled) .Values.loadBalancerService.port -}}
{{- end }}

{{/*
URL scheme used to reach the MapLarge container: https when tls.enabled is true, else http.
Also used as the container port name so service meshes can detect the protocol.
*/}}

{{- define "maplarge.scheme" -}}
  {{- ternary "https" "http" .Values.tls.enabled -}}
{{- end }}

{{/*
Contents of `cluster.json` file, typically located either in `/opt/maplarge/App_Data/config/cluster.json` or `/opt/maplarge/config/cluster.json`. Important because it is used to automatically join nodes to the cluster. Currently set to autojoin every node and make every node a voting member. This behavior may be changed in the near future so that only the first few nodes are set to be voting members.
*/}}

{{- define "maplarge.clusterConfigJson" }}
  {{- $namespace := .Release.Namespace }}
  {{- $statefulSetName := include "maplarge.fullname" . }}
  {{- $headlessServiceName := include "maplarge.headlessServiceName" . }}
  {{- $clusterConfigToMerge := .Values.clusterConfig }}
  {{- $port := include "maplarge.containerPort" . }}
  {{- $scheme := include "maplarge.scheme" . }}
  {{- $defaultSelfAddress := printf "%s://${HOSTNAME}.%s.%s:%d" $scheme $headlessServiceName .Release.Namespace (int $port) }}
  {{- /* Override via clusterConfig.DefaultClusterName, which wins the merge below. */}}
  {{- $defaultClusterName := "maplarge-cluster" }}
  {{- $autoJoinMembers := list }}
  {{- $upperIndex := default .Values.replicas .Values.numberOfAutoJoinMembers }}
  {{- range untilStep 0 (int $upperIndex) 1 }}
    {{- $autoJoinMembers = append $autoJoinMembers (printf "%s://%s-%d.%s.%s:%d" $scheme $statefulSetName (int .) $headlessServiceName $namespace (int $port)) }}
  {{- end }}
  {{- $clusterConfig := (dict "DefaultSelfAddress" $defaultSelfAddress "DefaultClusterName" $defaultClusterName "AutoJoinCoreClusterMembers" $autoJoinMembers ) }}
  {{- /* With fewer than 3 nodes the default replication criteria cannot be met and
       MapLarge logs a warning on every changeset; default the factor to 1 instead.
       A user-supplied clusterConfig.ChangeSetReplicationFactor wins the merge. */}}
  {{- if lt (int .Values.replicas) 3 }}
    {{- $_ := set $clusterConfig "ChangeSetReplicationFactor" 1 }}
  {{- end }}
  {{- $mergedClusterConfig := merge $clusterConfigToMerge $clusterConfig }}
  {{- $clusterConfigJson := toPrettyJson $mergedClusterConfig }}
  {{- $clusterConfigJson }}
{{- end }}

{{/*
Returns the proper service account name depending if an explicit service account name is set
in the values file. If the name is not set it will default the chart's generated name
*/}}
{{- define "maplarge.serviceAccountName" -}}
    {{- if .Values.serviceAccount.create -}}
        {{- if (empty .Values.serviceAccount.name) -}}
          {{- include "maplarge.fullname" . -}}
        {{- else -}}
          {{ default "default" .Values.serviceAccount.name }}
        {{- end -}}
    {{- else -}}
        {{ default "default" .Values.serviceAccount.name }}
    {{- end -}}
{{- end -}}

{{/*
Builds the js.js based on the inputs from the values if Notebooks are enabled.
*/}}
{{- define "maplarge.jsjs" }}
  {{- $jsjs := "" -}}
  {{- $nJsjs := "" -}}
  {{- if .Values.jsjs -}}
  {{- $jsjs = cat .Values.jsjs "\n" }}
  {{- end }}
  {{- if .Values.notebooks.enabled }}
  {{- $nJsjs = "ml.config.enableNotebooks = true;"}}
  {{- end }}
  {{- printf "%s%s" $jsjs $nJsjs}}
{{- end }}

{{/*
If the deployment needs a different hostname than the one defined in the ingress object, allow the user to specify
it as a value and use it, otherwise, we can just use the hostname from the ingress.
*/}}
{{- define "maplarge.hostname" -}}
  {{- if .Values.hostnameOverride -}}
  {{- .Values.hostnameOverride -}}
  {{- else if .Values.ingress.hosts -}}
  {{- (index .Values.ingress.hosts 0).baseHostname }}
  {{- end -}}
{{- end -}}


{{/*
Checks to see if this chart has been deployed with v1.X of the MapLarge helm chart. v2.X changes the name
of the PVC, and in doing so, will lose the data from the original 1.X version. If a pvc with app-data-<name>
is found, then it will be used vs. being updated.
*/}}
{{- define "maplarge.pvcName" -}}
{{ $search_for := printf "%s-%s" "app-data" $.Release.Name }}
{{ $pvc_name := "maplarge-data" }}
{{ $found := false }}

{{- range $index, $pvcs := (lookup "v1" "PersistentVolumeClaim" $.Release.Namespace "").items }}
  {{- $pvc := $pvcs.metadata.name }}
  {{- if and (not $found) (contains $search_for $pvc) -}}
    {{ $pvc_name = "app-data" }}
    {{ $found = true }}
  {{- end }}
{{- end }}

{{- printf "name: %s" $pvc_name }}
{{- end }}

{{/*
    Dumps variables to console and stops processing.  Used for debugging
    usage:  {{- template "maplarge.var_dump" $yourVariable }}
*/}}
{{- define "maplarge.var_dump" -}}
{{- . | mustToPrettyJson | printf "\nThe JSON output of the dumped var is: \n%s" | fail }}
{{- end -}}

{{/*
  Defines a name for the license, unless an existing secret has been provided
*/}}
{{- define "maplarge.licenseName" }}
{{- if .Values.license.existingSecretName }}
{{- .Values.license.existingSecretName }}
{{- else }}
{{- include "maplarge.fullname" . -}}-license
{{- end }}
{{- end }}


{{/*
Defines a name for the license directory as used by the File Globs
*/}}
{{- define "maplarge.licenseDir" }}
{{- $path := printf "%s/*" "license" }}
{{- printf "%s" $path }}
{{- end }}
